from django.contrib import admin
from .models import Skill, Project

# Register your models here.
admin.site.register(Skill)
admin.site.register(Project)